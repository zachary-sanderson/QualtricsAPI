﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using QualtricsAPI.Services;
using System.Threading.Tasks;
using QualtricsAPI.Models;
using QualtricsAPI.Services;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace QualtricsAPI.Controllers
{
    [Produces("application/json")]
    [Route("api/qualtrics")]
    [ApiController]
    public class QualtricsController : ControllerBase
    {
        private readonly IApiService apiService;

        public QualtricsController(IApiService apiService)
        {

            this.apiService = apiService;

        }

        [Route("GetResponse")]
        public async Task<string> GetResponse(string contactId)
        {
            contactId = "MLRP_1H6AWwJMqLu1FQx";
            string surveyResponse = await apiService.GetResponse(contactId);
            return surveyResponse;
        }

        [Route("GenerateLink")]
        public async Task<FullInfo> GenerateLink(Contact contact)
        {
            FullInfo info = await apiService.GenerateLink(contact);
            return info;
        }
    }
}
