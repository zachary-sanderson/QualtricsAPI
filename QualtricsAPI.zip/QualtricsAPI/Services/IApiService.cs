﻿using QualtricsAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace QualtricsAPI.Services
{
    public interface IApiService
    {
        Task<FullInfo> GenerateLink(Contact contact);
        Task<string> GetResponse(string contactId);
    }
}
