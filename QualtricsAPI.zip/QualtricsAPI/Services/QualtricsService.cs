﻿using QualtricsAPI.Models;
using Newtonsoft.Json;
using System;
using System.IO;
using System.Reflection;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using System.ComponentModel;
using System.Diagnostics;
using Newtonsoft.Json.Linq;

namespace QualtricsAPI.Services
{
    public class QualtricsService : IApiService
    {
        private HttpClient client = new HttpClient();

        private readonly string token = "K3a9WiR7AWuaVUGT57slt1T0Ddu6c6xbFTL2Z8i2";


        public QualtricsService()
        {
            
        }


        public async Task<string> GetResponse(string contactId)
        {
            //GET request that gets the responseId for the contact 
            string address = "https://exetercles.eu.qualtrics.com/API/v3/mailinglists/ML_5tn4ELjXtHkqCih/contacts/" + contactId;

            var client = new HttpClient();
            client.DefaultRequestHeaders.Add("X-API-TOKEN", token);
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            var response = await client.GetAsync(address);

            var json = await response.Content.ReadAsStringAsync();

            MailResponse result = JsonConvert.DeserializeObject<MailResponse>(json);

            string responseId = "";
            foreach(ResponseHistory history in result.result.responseHistory)
            {
                if(history.surveyId == "SV_5u4efYDWff9Q9Rb")
                {
                    responseId = history.responseId;
                }
            }  

            //GET request that gets the survey answers and returns them
            string responseAddress = "https://exetercles.eu.qualtrics.com/API/v3/surveys/SV_5u4efYDWff9Q9Rb/responses/" + responseId;

            var SVresponse = await client.GetAsync(responseAddress);

            var SVjson = await SVresponse.Content.ReadAsStringAsync();

            return SVjson;
        }



        public async Task<FullInfo> GenerateLink(Contact contact)
        {
            //POST request that creates a contact in the Mailing List based on information given.
            string address = "https://exetercles.eu.qualtrics.com/API/v3/mailinglists/ML_5tn4ELjXtHkqCih/contacts";

            var client = new HttpClient();
            client.DefaultRequestHeaders.Add("X-API-TOKEN", token);
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            var content = JsonConvert.SerializeObject(contact);
            var response = await client.PostAsync(address, new StringContent(content, Encoding.UTF8, "application/json"));


            //POST requests that generates a survey link for the new contact
            string GenAddress = "https://exetercles.eu.qualtrics.com/API/v3/distributions";

            LinkGenerator generator = new LinkGenerator();
            var GenContent = JsonConvert.SerializeObject(generator);

            var GenResponse = await client.PostAsync(GenAddress, new StringContent(GenContent, Encoding.UTF8, "application/json"));

            var GenJson = await GenResponse.Content.ReadAsStringAsync();

            GenLinkResponse GenResult = JsonConvert.DeserializeObject<GenLinkResponse>(GenJson);
            string link = GenResult.result.id;


            //GET request that grabs the participants survey link
            string GetAddress = "https://exetercles.eu.qualtrics.com/API/v3/distributions/" + link + "/links?surveyId=SV_5u4efYDWff9Q9Rb";

            var GetResponse = await client.GetAsync(GetAddress);

            var GetJson = await GetResponse.Content.ReadAsStringAsync();

            GetLinkResponse GetResult = JsonConvert.DeserializeObject<GetLinkResponse>(GetJson);
            foreach (FullInfo element in GetResult.result.elements)
            {
                if (element.email == contact.email)
                {
                    return element;
                }
            }
            //If search for participant's link fails, returns an empty FullInfo object and gives an error message
            FullInfo info = new FullInfo();
            return info;
            throw new Exception("Failed to find survey link for the generated contact, please try again.");
        }
    }
}
