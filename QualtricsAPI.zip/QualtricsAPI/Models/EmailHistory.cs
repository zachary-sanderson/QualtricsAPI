﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QualtricsAPI.Models
{
    public class EmailHistory
    {
        public string emailDistributionId { get; set; }
        public string date { get; set; }
        public string type { get; set; }
        public int result { get; set; }
        public string read { get; set; }
        public string surveyId { get; set; }
    }
}
