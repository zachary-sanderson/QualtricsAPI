﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QualtricsAPI.Models
{
    abstract class Result { }

    class Meta
    {
        public string httpStatus { get; set; }
        public string requestId { get; set; }
    }

    class GenLinkResponse 
    {
        public class Result
        {
            public string id { get; set; }
        }
        public Result result { get; set; }
        public Meta meta { get; set; }
    }

    class GetLinkResponse 
    {
        public class Result
        {
            public FullInfo[] elements { get; set; }
            public string nextPage { get; set; }
        }
        public Result result { get; set; }
        public Meta meta { get; set; }
    }

    class MailResponse
    {
        public class Result
        {
            public string id { get; set; }
            public string firstName { get; set; }
            public string lastName { get; set; }
            public string email { get; set; }
            public string externalDataReference { get; set; }
            public string embeddedData { get; set; }
            public string language { get; set; }
            public string unsubscribed { get; set; }
            public ResponseHistory[] responseHistory { get; set; }
            public EmailHistory[] emailHistory { get; set; }
        }
        public Result result { get; set; }
        public Meta meta { get; set; }
    }
    
    class SurveyResponse
    {
        public class Result
        {
            public Values values { get; set; }
            public Labels labels { get; set; }
            public string[] displayedFields { get; set; }
            public DisplayedValues displayedValues { get; set; }
        }
        public Result result { get; set; }
        public Meta meta { get; set; }
    }
}
