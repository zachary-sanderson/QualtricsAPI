﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QualtricsAPI.Models
{
    public class ResponseHistory
    {
        public string responseId { get; set; }
        public string surveyId { get; set; }
        public string date { get; set; }
        public string emailDistributionId { get; set; }
        public string finishedSurvey { get; set; }
    }
}
