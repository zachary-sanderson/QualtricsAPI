﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QualtricsAPI.Models
{
    public class Labels
    {
        public string status { get; set; }
        public string finished { get; set; }
        public string QID1225 { get; set; }
        public string[] QID1225_DO { get; set; }
        public string QID409 { get; set; }
        public string[] QID409_DO { get; set; }
        public string QID753_4 { get; set; }
        public string QID753_5 { get; set; }
        public string QID753_6 { get; set; }
        public string QID753_7 { get; set; }
        public string QID753_8 { get; set; }
        public string QID753_9 { get; set; }
        public string QID753_10 { get; set; }
        public string QID753_11 { get; set; }
        public string QID753_12 { get; set; }
        public string QID753_13 { get; set; }
        public string QID753_14 { get; set; }
        public string QID753_15 { get; set; }
        public string QID753_16 { get; set; }
        public string QID753_17 { get; set; }
        public string[] QID753_DO { get; set; }
        public string QID926 { get; set; }
        public string[] QID926_DO { get; set; }
        public string QID928 { get; set; }
        public string[] QID928_DO { get; set; }
        public string QID929 { get; set; }
        public string[] QID929_DO { get; set; }
        public string QID933 { get; set; }
        public string[] QID933_DO { get; set; }
        public string QID934 { get; set; }
        public string[] QID934_DO { get; set; }
        public string QID935 { get; set; }
        public string[] QID935_DO { get; set; }
        public string QID1004 { get; set; }
        public string[] QID1004_DO { get; set; }
        public string QID938 { get; set; }
        public string[] QID938_DO { get; set; }
        public string QID941 { get; set; }
        public string[] QID941_DO { get; set; }
        public string QID942 { get; set; }
        public string[] QID942_DO { get; set; }
        public string QID943 { get; set; }
        public string[] QID943_DO { get; set; }
        public string QID945 { get; set; }
        public string[] QID945_DO { get; set; }
        public string QID946 { get; set; }
        public string[] QID946_DO { get; set; }
        public string QID947 { get; set; }
        public string[] QID947_DO { get; set; }
        public string QID948 { get; set; }
        public string[] QID948_DO { get; set; }
        public string QID949 { get; set; }
        public string[] QID949_DO { get; set; }
        public string QID950 { get; set; }
        public string[] QID950_DO { get; set; }
        public string QID951 { get; set; }
        public string[] QID951_DO { get; set; }
        public string QID953 { get; set; }
        public string[] QID953_DO { get; set; }
        public string QID954 { get; set; }
        public string[] QID954_DO { get; set; }
        public string QID955 { get; set; }
        public string[] QID955_DO { get; set; }
        public string[] QID957 { get; set; }
        public string[] QID957_DO { get; set; }
        public string[] QID959 { get; set; }
        public string[] QID959_DO { get; set; }
        public string[] QID961 { get; set; }
        public string[] QID961_DO { get; set; }
        public string QID963 { get; set; }
        public string[] QID963_DO { get; set; }
        public string QID159_1 { get; set; }
        public string QID159_10 { get; set; }
        public string QID159_11 { get; set; }
        public string QID159_12 { get; set; }
        public string QID159_13 { get; set; }
        public string QID159_14 { get; set; }
        public string QID159_15 { get; set; }
        public string QID159_16 { get; set; }
        public string QID159_19 { get; set; }
        public string[] QID159_DO { get; set; }
    }
}
