﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QualtricsAPI.Models
{
    public class LinkGenerator
    {
        public string surveyId { get; set; } = "SV_5u4efYDWff9Q9Rb";
        public string linkType { get; set; } = "Individual";
        public string description { get; set; } = "Qualtrics Surveys 2019";
        public string action { get; set; } = "CreateDistribution";
        public string expirationDate { get; set; } = "2019-12-31 00:00:00";
        public string mailingListId { get; set; } = "ML_5tn4ELjXtHkqCih";
    }
}
