﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QualtricsAPI.Models
{
    public class DisplayedValues
    {
        public int[] QID948 { get; set; }
        public int[] QID947 { get; set; }
        public int[] QID949 { get; set; }
        public int[] QID159_13 { get; set; }
        public int[] QID159_14 { get; set; }
        public int[] QID943 { get; set; }
        public int[] QID159_15 { get; set; }
        public int[] QID946 { get; set; }
        public int[] QID159_16 { get; set; }
        public int[] QID945 { get; set; }
        public int[] QID159_19 { get; set; }
        public int[] QID942 { get; set; }
        public int[] QID941 { get; set; }
        public int[] QID159_10 { get; set; }
        public int[] QID159_11 { get; set; }
        public int[] QID159_12 { get; set; }
        public int[] QID959 { get; set; }
        public int[] QID955 { get; set; }
        public int[] QID1004{ get; set; }
        public int[] QID954 { get; set; }
        public int[] QID957 { get; set; }
        public int[] QID951 { get; set; }
        public int[] QID950 { get; set; }
        public int[] QID953 { get; set; }
        public int[] QID929 { get; set; }
        public int[] QID926 { get; set; }
        public int[] QID409 { get; set; }
        public int[] QID928 { get; set; }
        public int[] QID753_5 { get; set; }
        public int[] QID753_4 { get; set; }
        public int[] QID753_11 { get; set; }
        public int[] QID961 { get; set; }
        public int[] QID753_12 { get; set; }
        public int[] QID963 { get; set; }
        public int[] QID753_10 { get; set; }
        public int[] QID753_15 { get; set; }
        public int[] QID753_16 { get; set; }
        public int[] QID753_13 { get; set; }
        public int[] QID753_14 { get; set; }
        public int[] QID753_17 { get; set; }
        public int[] QID159_1 { get; set; }
        public int[] QID753_9 { get; set; }
        public int[] QID753_8 { get; set; }
        public int[] QID753_7 { get; set; }
        public int[] QID1225 { get; set; }
        public int[] QID753_6 { get; set; }
        public int[] QID938 { get; set; }
        public int[] QID933 { get; set; }
        public int[] QID935 { get; set; }
        public int[] QID934 { get; set; }
    }
}
